dictest = {}
dictest ['var1'] = 'gato'
dictest['var2'] = 'cachorro'
print(dictest.keys())