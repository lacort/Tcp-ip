b'\xc0\xa8\x01\x01\xff\xff\xff\x00@4\x89R\x12 \xc0\xa8\x01\xeb\x12\xc0\x085114'

import socket
#from time import sleep
from ModuloUtils import replyAddress,splitFields,splitFields2

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
s.setblocking(True)
s.bind(('', 2102))

send_address = ('192.168.1.255', 2106)
file = open('lista.txt.py', 'r')
texto = file.read().split()
file.close()


if len(texto) == 0:
    strNewIpAddress = '192.168.1.10'
    strNewMask = '255.255.255.0'
    strNewGateway ='192.168.1.1'
    strNewMac = '0:0:0:0:0:0'
    strNewBaund = '9.96'
    strNewPort = '8.53'
    strNewVersion = '49.49.54'
    strNewSocket = '1'
    strNewName = '115.112.105.100.101.114.32.32.32.32'

else:
    strNewIpAddress = texto[0]
    strNewMask = texto[1]
    strNewGateway = texto[2]
    strNewMac = texto[3]
    strNewBaund = texto[4]
    strNewPort = texto[5]
    strNewVersion =texto[6]
    strNewSocket = [7]
    strNewName = [8]




while 1:


    message, address = s.recvfrom(8192)
    if message == b'SETUP':
       # print(message)
        message = b'\xc0\xa8\x01\x01\xff\xff\xff\x00@4\x89R\x12 \xc0\xa8\x01\xeb\x12\xc0\x085114'

        NewFrame = []

        NewFrame.extend(replyAddress(receive=strNewGateway))
        NewFrame.extend(replyAddress(receive=strNewMask))
        NewFrame.extend(replyAddress(receive=strNewMac))
        NewFrame.extend(replyAddress(receive=strNewIpAddress))
        NewFrame.extend(replyAddress(receive=strNewBaund))
        NewFrame.extend(replyAddress(receive=strNewPort))
        #NewFrame.extend(replyAddress(receive=strNewVersion))
        NewFrame.extend([1])
        NewFrame.extend(replyAddress(receive=strNewName))

        bield = bytearray(NewFrame)



        resposta =  bield
        s.sendto(resposta, send_address)


    elif len(message) :

        strIpAddress = ''
        strMask = ''
        strGateway = ''
        strMac = ''
        strBaund = ''
        strPort = ''
        strVersion = ''
        strSocket = ''
        strName = ''

        strGateway = splitFields2(message, 'Gateway')
        strMask = splitFields2(message, 'Mask')
        strMac = splitFields2(message, 'Mac')
        strIpAddress = splitFields2(message, 'Ip')
        strBaund = splitFields2(message, 'Baund')
        strPort = splitFields2(message, 'Port')
        #strVersion = splitFields2(message, 'Version')
        strSocket = splitFields2(message, 'Socket')
        strName = splitFields2(message, 'Name')

        NewFrame = []

        NewFrame.extend(replyAddress(receive=strGateway))
        NewFrame.extend(replyAddress(receive=strMask))
        NewFrame.extend(replyAddress(receive=strMac))
        NewFrame.extend(replyAddress(receive=strIpAddress))
        NewFrame.extend(replyAddress(receive=strBaund))
        NewFrame.extend(replyAddress(receive=strPort))
        #NewFrame.extend(replyAddress(receive=strVersion))
        NewFrame.extend([1])
        NewFrame.extend(replyAddress(receive=strName))


        strNewIpAddress = str(strIpAddress)
        strNewMask = str(strMask)
        strNewGateway = str(strGateway)
        strNewMac = str(strMac)
        strNewBaund = str(strBaund)
        strNewPort = str(strPort)
        strNewVersion = str(strVersion)
        strNewSocket = str(strSocket)
        strNewName = str(strName)


        bield = bytearray(NewFrame)

        file = open('lista.txt.py', 'w')
        texto = []
        texto.append(strIpAddress)
        texto.append(' ')
        texto.append(strMask)
        texto.append(' ')
        texto.append(strGateway)
        texto.append(' ')
        texto.append(strMac)
        texto.append(' ')
        texto.append(strBaund)
        texto.append(' ')
        texto.append(strPort)
        texto.append(' ')
        texto.append(strName)
        file.writelines(texto)
        file.close()

        resposta = bield
        s.sendto(resposta, send_address)
