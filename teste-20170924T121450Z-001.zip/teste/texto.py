import socket
from ModuloUtils import splitFields

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
s.setblocking(True)
s.bind(('', 2106))

send_address = ('192.168.1.255', 2102)
strtext = 'SETUP'
s.sendto(strtext.encode(), send_address)
listModulos = []
listIp = []
cont = 1
while 1:
    try:
        message, address = s.recvfrom(8192)
        index=0
        for  temp in (message):
            print(temp)
            index+=1
        listModulos.append(message)

        if message:
            strIpAddress = ''
            strMask = ''
            strGateway = ''
            strMac = ''
            strVersion =''

            strIpAddress = splitFields(message, 'Ip')

            strMask = splitFields(message, 'Mask')

            strGateway = splitFields(message, 'Gateway')

            strMac = splitFields(message, 'Mac')

            strBaund = splitFields(message, 'Baund')

            strVersion = splitFields(message, 'Version')
            print( '{} IP: {}  Mac: {} Versão: {}\n'.format(cont, strIpAddress, strMac, strVersion))
            cont = cont + 1
        listIp.append(strIpAddress)






    except:
         pass
else:

    strCohiceIpAddress = str(input('Escolha o número do Ip que deseja configurar: '))

